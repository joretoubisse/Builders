The System is using Sessions not cookies or claims


#Login Page has all the primary sessions
1. Session["UsersID"] = This is the users Primary Key
2. Session["Campus"] = Benoni/Delmas/
3. Session["ShowAll"] = YES then this will pull all details for All Campuses (E.g on Members page it will pull for all Members in all campuses)
4. Session["ChurchID"] = This is the Church ID but in your case there will be one church ID.
5. Session["LoggedIn"] = True // This is set to true and will expire after 40Min with no action; if expired then forces users to login again.
6. Session["MemberNo"] = B_Church = All Members are given a random number which is added after MemberNo  - This is because we are not capturing their ID's 
7. Session["URL"] = This will give you the Root URL: eg:localhost/index.html
8. Session["FilePath"] This will give you the filepath: eg: C:\Users\Jabulani Msomi\Desktop\buildersonline.org.za\BuildersOnline
9. Session["ChurchName"] = "Builders Church"
10. Session["identifier"] =  In case you want to start tracking the users journey in full you can use this token/identifier




//Set Access rights within Modules 
If the Below  == 1 then you will have full rights and you will see the action buttons
Session["AdminRight"] 
Session["MemberRight"] 
Session["VisitorRight"] 
Session["KidsRights"] 
Session["Attendance"] 
Session["NotieRights"] 
Session["Offering"]
Session["NewMemberRights"] 
Session["ConnectRight"] 
Session["EventRights"]
Session["Resources"] 
Session["Iserver"] 
Session["Evangelism"]
Session["ReportsRights"] 
#end

#Menu Set up 
Menu is built from a class called "MenuDatatble.cs"
A user will only see menu tabs that are assign to them.
SQL table : MenuItems
#End




#SQL
We use a class called : SqlConnMethod
You just need to pass your queries to the method you need.
Check WebConfig for server detais
#end


All pages have the same layout.
1.  if (Session["LoggedIn"] != null) Check if the session is still alive
2. RunOnLoad() //Run on load basically runs all your functions you need to load 
3. if (ConfigurationManager.AppSettings["HideFields"].ToString() == "1") // This was used for Troubleshooting in Live but no longer needed





